# ساختار داده

پنج جدول، همه InnoDB، همه با collation سرور (از `$wpdb->get_charset_collate()`)،
همه با پیشوند `{$wpdb->prefix}mjy_`.

> چرا InnoDB: قفل سطح‌ردیف (یک اجرای صف نباید فروشگاه را قفل کند)،
> تراکنش (درج ردیف انتظار + صف شدن پیام باید با هم موفق یا با هم ناموفق باشند)،
> و بازیابی پس از کرش.

## ۱) `mjy_waitlists` — اشتراک‌ها

| ستون | نوع | توضیح |
|---|---|---|
| `id` | BIGINT UNSIGNED AI | کلید اصلی |
| `token` | CHAR(64) | توکن تآیید/لغو؛ یکتا |
| `product_id` | BIGINT UNSIGNED | محصول |
| `variation_id` | BIGINT UNSIGNED (0) | تنوع، یا ۰ برای محصول ساده |
| `event_type` | VARCHAR(32) | پیش‌فرض `restock` (باز برای رویدادهای آینده) |
| `channel` | VARCHAR(16) | `email` یا `sms` |
| `email` | VARCHAR(190) NOT NULL DEFAULT '' | خالی برای ردیف‌های فقط‌پیامک |
| `phone` | VARCHAR(20) NOT NULL DEFAULT '' | نرمال‌شده به `09xxxxxxxxx` |
| `full_name` | VARCHAR(120) NOT NULL DEFAULT '' | نامی که خودِ مشتری در فرم نوشته؛ خالی = بی‌نام |
| `user_id` | BIGINT UNSIGNED (0) | ۰ = مهمان |
| `status` | VARCHAR(16) | `pending` / `confirmed` / `unsubscribed` / `notified` / `expired` |
| `registration_cycle` | BIGINT UNSIGNED (0) | شمارهٔ دورهٔ ثبت؛ در ثبت مجدد ردیف غیرفعال افزایش می‌یابد |
| `consent_at` | DATETIME NULL | زمان رضایت |
| `confirmed_at` | DATETIME NULL | زمان تآیید دومرحله‌ای |
| `notified_at` | DATETIME NULL | آخرین اعلان |
| `confirm_expires_at` | DATETIME NULL | انقضای توکن (پیش‌فرض +۴۸ ساعت) |
| `stock_at_signup` | INT | موجودی لحظهٔ ثبت (۰ = ناموجود) |
| `ip_hash` | CHAR(64) | SHA-256 نمکی IP — **IP خام هرگز ذخیره نمی‌شود** |
| `called_at` | DATETIME NULL | زمان آخرین تماس ثبت‌شده؛ NULL = هیچ تماسی ثبت نشده |
| `called_by` | BIGINT UNSIGNED (0) | کاربری که آخرین تماس را ثبت کرد |
| `call_state` | VARCHAR(16) NOT NULL DEFAULT 'open' | `open` (در جریان) یا `closed` (خاتمه‌یافته) |
| `call_closed_at` | DATETIME NULL | زمان خاتمه |
| `call_closed_by` | BIGINT UNSIGNED (0) | کاربری که پیگیری را بست |
| `call_close_reason` | VARCHAR(32) NOT NULL DEFAULT '' | کد دلیل خاتمه (کلیدهای `CallLog::CLOSE_REASONS`) |
| `call_close_note` | VARCHAR(190) NOT NULL DEFAULT '' | توضیح خاتمه |
| `created_at` | DATETIME | زمان ثبت دورهٔ جاری؛ در ثبت مجدد تازه می‌شود و مبنای نوبت و نگهداشت است |

کلیدها:

- `UNIQUE uniq_token (token)` — جلوگیری از تصادم توکن.
- `UNIQUE uniq_subscriber (product_id, variation_id, email, phone)` — یک نفر
  برای یک محصول/تنوع دو بار ثبت نمی‌شود. چون NULL در MySQL یکتا نیست،
  ستون‌های ایمیل/موبایل `NOT NULL DEFAULT ''` هستند.
- `KEY idx_status_product (status, product_id, variation_id)` — کویری اصلی
  fair sending.
- `KEY idx_status_created (status, created_at)` — پیمایش «قدیمی‌تر اول».
- `KEY idx_phone`, `KEY idx_email`, `KEY idx_name` — جست‌وجوی ادمین (ایمیل،
  موبایل یا نام).
- `KEY idx_call_state (call_state)` — جدا کردن پیگیری‌های بسته از لیست کار.
- `KEY idx_called (called_at)` — فیلتر «تماس گرفته شده / نشده» بدون
  اسکن کل جدول.

## ۲) `mjy_stock_snapshots` — تصویر موجودی

| ستون | نوع | توضیح |
|---|---|---|
| `product_id` | BIGINT UNSIGNED | بخشی از PK |
| `variation_id` | BIGINT UNSIGNED (0) | بخشی از PK |
| `stock_status` | VARCHAR(16) | `instock` / `outofstock` / `onbackorder` |
| `stock_qty` | INT | آخرین تعداد دیده‌شده |
| `is_managed` | TINYINT(1) | آیا موجودی مدیریت می‌شود |
| `announced_qty` | INT | موجودی‌ای که برایش اعلان صادر شد |
| `announced_at` | DATETIME NULL | زمان آن اعلان |
| `checked_at` | DATETIME | آخرین بازبینی |

کلیدها: `PRIMARY KEY (product_id, variation_id)`، `KEY idx_status (stock_status, checked_at)`.

`announced_qty` پایهٔ محاسبهٔ تعداد قابل تخصیص در حالت منصفانه است. اعلان
خودکار به گذار وضعیت از ناموجود به موجود وابسته است؛ افزایش تعداد در حالی که
وضعیت همچنان موجود مانده، الزاماً اعلان تازه ایجاد نمی‌کند. به‌روزرسانی اتمی
snapshot برای هوک تکراری همان گذار از ساخت دوبارهٔ صف جلوگیری می‌کند؛ رقابت
واقعی MySQL/InnoDB در این محیط آزمایش نشده است.

## ۳) `mjy_queue` — صف ارسال

| ستون | نوع | توضیح |
|---|---|---|
| `id` | BIGINT UNSIGNED AI | کلید اصلی |
| `waitlist_id` | BIGINT UNSIGNED | ارجاع به اشتراک |
| `registration_cycle` | BIGINT UNSIGNED (0) | دوره‌ای که پیام به آن تعلق دارد؛ پیام دورهٔ قدیمی ارسال نمی‌شود |
| `channel` | VARCHAR(16) | `email` / `sms` |
| `event_key` | VARCHAR(100) | `confirm` یا `restock:<ts>:<rand>` |
| `payload_hash` | CHAR(64) | هش شناسه، کانال، رویداد، داده و دوره برای جلوگیری از درج تکراری |
| `attempts` | TINYINT UNSIGNED | تعداد تلاش |
| `status` | VARCHAR(16) | `queued` / `processing` / `sent` / `failed` / `blocked` / `skipped` |
| `next_run_at` | DATETIME | زمان مجاز تلاش بعدی |
| `last_error` | VARCHAR(255) NULL | آخرین خطا (`unsubscribed`, `not_confirmed`, …) |
| `locked_at` | DATETIME NULL | **قفل نرم** برای جلوگیری از پردازش هم‌زمان |
| `sent_at` | DATETIME NULL | زمان ارسال موفق |
| `created_at` | DATETIME | — |

کلیدها:

- `UNIQUE uniq_payload (waitlist_id, payload_hash)` — همان شخص، همان پیام،
  فقط یک بار در صف.
- `KEY idx_run (status, next_run_at)` — انتخاب دسته.
- `KEY idx_waitlist (waitlist_id)` — پاک‌سازی آبشاری منطقی.
- `KEY idx_sent (status, sent_at)` — شمارش نرخ دقیقه.

## ۴) `mjy_call_log` — تاریخچهٔ تماس‌های پیگیری

یک ردیف برای هر تماس. مرحله («تماس اول»، «تماس دوم»…) **ذخیره نمی‌شود**؛ از
تعداد ردیف‌های همین جدول برای آن مشترک ساخته می‌شود، تا دو کاربر که همزمان ثبت
می‌کنند دو «تماس دوم» نسازند.

| ستون | نوع | توضیح |
|---|---|---|
| `id` | BIGINT UNSIGNED AI | کلید اصلی |
| `waitlist_id` | BIGINT UNSIGNED | ردیف لیست انتظار |
| `stage` | INT UNSIGNED | شمارهٔ مرحله در لحظهٔ ثبت (برای نمایش و مرتب‌سازی) |
| `outcome` | VARCHAR(32) | کد نتیجه؛ کلیدهای `CallLog::OUTCOMES` |
| `note` | VARCHAR(500) | توضیح تایپ‌شده؛ پاک‌سازی‌شده و محدود |
| `user_id` | BIGINT UNSIGNED (0) | کاربری که تماس گرفت |
| `created_at` | DATETIME | زمان ثبت |

- `KEY idx_waitlist_stage (waitlist_id, stage)` — تاریخچهٔ یک مشترک.
- `KEY idx_created (created_at)` — گزارش‌های زمانی.

> **بدون کلید خارجی:** این افزونه FK نمی‌سازد (بعضی هاست‌ها و موتورهای قدیمی
> مشکل دارند). حذف ردیف لیست انتظار، ردیف‌های تاریخچه را رها می‌کند؛ پاک‌سازی
> هنگام حذف ردیف در `delete_row()` انجام می‌شود و در آزمون بررسی شده است.

## ۵) `mjy_logs` — لاگ امنیتی و شمارش نرخ

| ستون | نوع | توضیح |
|---|---|---|
| `id` | BIGINT UNSIGNED AI | — |
| `level` | VARCHAR(16) | `info` / `warning` / `error` |
| `event` | VARCHAR(64) | `subscribe_rate_limited`, `queue_sent`, … |
| `context` | VARCHAR(255) | متن کوتاه، بدون دادهٔ شخصی |
| `ip_hash` | CHAR(64) | برای شمارش ۵/ساعت |
| `created_at` | DATETIME | — |

کلیدها: `KEY idx_event_created (event, created_at)`، `KEY idx_level (level)`.

لاگ **هرگز** ایمیل/موبایل خام ندارد؛ فقط هش IP و نام رویداد.

## ۶) نگهداشت و حذف

| داده | سیاست |
|---|---|
| ردیف‌های `notified`/`expired`/`unsubscribed` با `created_at` قدیمی‌تر از `retention_days` (پیش‌فرض ۱۸۰) | پاک‌سازی زمان‌بندی‌شده؛ در ثبت مجدد `created_at` تازه می‌شود |
| لاگ‌های قدیمی‌تر از ۹۰ روز | پاک‌سازی زمان‌بندی‌شده |
| صف مربوط به ردیف حذف‌شده | همراه حذف ردیف انتظار پاک می‌شود؛ حذف جداگانهٔ همهٔ `sent`های ۳۰روزه پیاده‌سازی نشده است |
| حذف افزونه | فقط اگر مدیر `delete_data_on_uninstall` را روشن کرده باشد |

## ۷) مهاجرت

`MOJODYAR_DB_VERSION = '5'` نسخهٔ داخلی ساختار است و شمارهٔ عمومی افزونه
همچنان ۱.۰.۰ است. `Activator::maybe_upgrade()` نسخهٔ ذخیره‌شده را مقایسه
می‌کند و در صورت اختلاف `Database::install()` را با `dbDelta` فراخوانی می‌کند.
داده‌های پیشین در دورهٔ صفر باقی می‌مانند. اگر دو ستون دوره در دسترس نباشند،
نسخهٔ ساختار موفق ثبت نمی‌شود و ثبت، پردازش صف و پایش تا ارتقای موفق متوقف‌اند.

`dbDelta` گاهی موتور جدول موجود را تغییر نمی‌دهد؛ `Database::force_innodb()`
پس از هر نصب، `SHOW TABLE STATUS` می‌گیرد و در صورت نیاز
`ALTER TABLE … ENGINE=InnoDB` اجرا می‌کند. اگر `SHOW` در دسترس نباشد
(بعضی هاست‌های محدود)، بی‌صدا رد می‌شود و افزونه کار می‌کند.

## ۸) آنچه اندازه‌گیری نشد

- کارایی این پنج جدول روی MySQL با ۱۰۰٬۰۰۰+ ردیف واقعی. `tests/load.php`
  ده‌هزار ردیف را روی SQLite می‌آزماید و صریحاً می‌گوید «بنچمارک MySQL نیست».
- رفتار `ALTER TABLE … ENGINE=InnoDB` روی جدولی که حجم زیادی داده دارد
  (می‌تواند کند باشد؛ روی فروشگاه‌های بزرگ یک بار اجرا می‌شود و تمام).
